package com.mata.persfume.event.model.service;

public interface EventService {

}
