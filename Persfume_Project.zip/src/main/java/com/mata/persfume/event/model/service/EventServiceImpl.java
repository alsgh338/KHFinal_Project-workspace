package com.mata.persfume.event.model.service;

public class EventServiceImpl implements EventService {

}
