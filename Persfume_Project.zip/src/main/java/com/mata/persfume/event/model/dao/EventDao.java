package com.mata.persfume.event.model.dao;

public class EventDao {

}
