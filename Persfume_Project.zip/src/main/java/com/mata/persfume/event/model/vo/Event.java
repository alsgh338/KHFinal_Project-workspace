package com.mata.persfume.event.model.vo;

public class Event {

}
