package com.mata.persfume.product.model.service;

public class ProductServiceImpl implements ProductService {

}
