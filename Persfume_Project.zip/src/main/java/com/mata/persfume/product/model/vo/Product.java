package com.mata.persfume.product.model.vo;

public class Product {

}
