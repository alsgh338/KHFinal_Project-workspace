package com.mata.persfume.product.model.dao;

public class ProductDao {

}
