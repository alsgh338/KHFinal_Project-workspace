package com.mata.persfume.product.model.service;

public interface ProductService {

}
