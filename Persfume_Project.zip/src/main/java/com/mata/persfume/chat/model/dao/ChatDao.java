package com.mata.persfume.chat.model.dao;

public class ChatDao {

}
