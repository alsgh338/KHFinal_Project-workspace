package com.mata.persfume.chat.model.vo;

public class Chat {

}
