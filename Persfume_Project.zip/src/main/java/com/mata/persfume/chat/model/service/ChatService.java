package com.mata.persfume.chat.model.service;

public interface ChatService {

}
