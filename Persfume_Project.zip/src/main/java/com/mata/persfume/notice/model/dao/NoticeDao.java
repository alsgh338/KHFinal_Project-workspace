package com.mata.persfume.notice.model.dao;

public class NoticeDao {

}
