package com.mata.persfume.notice.model.vo;

public class Notice {

}
