package com.mata.persfume.notice.model.service;

public class NoticeServiceImpl implements NoticeService {

}
