package com.mata.persfume.notice.controller;

public class NoticeController {

}
