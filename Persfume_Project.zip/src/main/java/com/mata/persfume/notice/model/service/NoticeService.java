package com.mata.persfume.notice.model.service;

public interface NoticeService {

}
