package com.mata.persfume.common.template;

public class Pagination {

}
