package com.mata.persfume.common.interceptor;

public class LoginInterceptor {

}
