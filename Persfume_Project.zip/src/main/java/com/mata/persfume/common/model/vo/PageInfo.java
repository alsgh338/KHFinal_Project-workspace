package com.mata.persfume.common.model.vo;

public class PageInfo {

}
