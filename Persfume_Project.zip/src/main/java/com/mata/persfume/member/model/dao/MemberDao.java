package com.mata.persfume.member.model.dao;

public class MemberDao {

}
