package com.mata.persfume.member.model.service;

public interface MemberService {

}
