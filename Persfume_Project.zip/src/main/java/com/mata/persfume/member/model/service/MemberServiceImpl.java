package com.mata.persfume.member.model.service;

public class MemberServiceImpl implements MemberService {

}
