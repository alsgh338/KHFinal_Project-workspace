package com.mata.persfume.member.model.vo;

public class Member {

	private int memNo;
	private String memId;
	private String memPwd;
	private String memName;
	private String email;
	private String phone;
	private String addressNo;
	private String address;
	private String gender;
	private Date birthDate;
	private Date enrollDate;
	private Date modifyDate;
	private Date testDate;
	private String status;
	
}
