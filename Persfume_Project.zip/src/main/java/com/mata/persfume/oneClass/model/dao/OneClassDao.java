package com.mata.persfume.oneClass.model.dao;

public class OneClassDao {

}
