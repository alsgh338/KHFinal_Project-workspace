package com.mata.persfume.oneClass.controller;

public class OneClassController {

}
