package com.mata.persfume.oneClass.model.service;

public class OneClassServiceImpl implements OneClassService {

}
