package com.mata.persfume.oneClass.model.vo;

public class OneClass {

}
