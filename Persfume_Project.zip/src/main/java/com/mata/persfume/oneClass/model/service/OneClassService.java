package com.mata.persfume.oneClass.model.service;

public interface OneClassService {

}
